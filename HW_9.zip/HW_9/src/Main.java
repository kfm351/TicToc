public class Main {
    // Точка входа
    public static void main(String[] args) {
        // Создаём объект игры
        Game game = new Game();
        // Запускаем игру
        game.start();
    }
}

